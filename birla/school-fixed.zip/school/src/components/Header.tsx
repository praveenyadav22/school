"use client";

import Link from "next/link";
import { useState, useEffect } from "react";

const Header = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isFixed, setIsFixed] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsFixed(window.scrollY > 100);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (sidebarOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [sidebarOpen]);

  return (
    <>
      <header className="c-header">
        {/* ── Top Bar ── */}
        <div className="c-header__top">
          <div className="container">
            <div className="row">
              <div className="col-12">
                <div className="c-header__top--content">
                  <ul className="left-content">
                    <li className="left-content--item">
                      <Link href="/vacancy" className="link">Vacancy</Link>
                    </li>
                    <li className="left-content--item">
                      <a href="https://erp.quickcampus.online/auth" className="link" target="_blank" rel="noreferrer">
                        Student Login
                      </a>
                    </li>
                    <li className="left-content--item">
                      <a href="https://erp.quickcampus.online/auth" className="link" target="_blank" rel="noreferrer">
                        Staff Login
                      </a>
                    </li>
                  </ul>
                  <ul className="right-content">
                    <li className="right-content--item">
                      <Link href="/admission" className="link">Admission</Link>
                    </li>
                    <li className="right-content--item">
                      <Link href="/pay-online" className="link">Pay Online</Link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ── Bottom Bar ── */}
        <div className={`c-header__bottom${isFixed ? " fixedmenu" : ""}`}>
          <div className="container">
            <div className="row">
              <div className="col-12">
                <div className="c-header__bottom--content">
                  {/* Desktop logo (shows on xl+, positioned above nav) */}
                  <div className="header-logo">
                    <Link href="/" className="link">
                      <img src="/images/logo/bvn-logo.png" alt="BVN Logo" />
                    </Link>
                  </div>

                  {/* Mobile logo */}
                  <div className="mobile-logo">
                    <Link href="/" className="link">
                     <img src="/images/logo/bvn-logo.png" alt="BVN Logo" />
                    </Link>
                  </div>

                  {/* Navigation + sidebar trigger */}
                  <div className="menu-section">
                    <div className="navigationsection">
                      <div className="c-navigationwrap">
                        <nav className="stellarnav dark left desktop">
                          <ul style={{ display: "block" }}>
                            {/* About Us */}
                            <li className="has-sub">
                              <a href="javascript:void(0)">
                                About Us <i className="ri-arrow-down-s-line" />
                              </a>
                              <ul className="sub-menu">
                                <li><Link href="/school-profile">School Profile</Link></li>
                                <li><Link href="/vision-mission">Vision and Mission</Link></li>
                                <li><Link href="/founders">Founders</Link></li>
                                <li><Link href="/chairperson">Chairperson</Link></li>
                                <li><Link href="/director-manager">Director &amp; Manager</Link></li>
                                <li><Link href="/principal">Principal</Link></li>
                                <li className="nav-item has-sub">
                                  <a href="#" className="nav-link dropdown-toggle">
                                    Vice Principal <i className="ri-arrow-right-s-line" aria-hidden="true" style={{ color: "#a43605", float: "right" }} />
                                  </a>
                                  <ul className="dropdown-menu">
                                    <li className="nav-item"><Link className="nav-link" href="/sr-section">Sr. Section</Link></li>
                                  </ul>
                                </li>
                                <li><Link href="/head-mistress">Head Mistress</Link></li>
                                <li><Link href="/school-managing-committee">School Managing Committee</Link></li>
                                <li><Link href="/faculty">Faculty</Link></li>
                                <li><Link href="/pta">PTA</Link></li>
                                <li><Link href="/internal-committee">Internal Committee</Link></li>
                                <li><Link href="/mandatory-public-disclosure">Mandatory Public Disclosure</Link></li>
                              </ul>
                            </li>

                            {/* CBSE Results */}
                            <li className="has-sub">
                              <a href="javascript:void(0)">
                                CBSE Results <i className="ri-arrow-down-s-line" />
                              </a>
                              <ul className="sub-menu">
                                <li><Link href="/class-xii">Class XII</Link></li>
                                <li><Link href="/class-x">Class X</Link></li>
                                <li><Link href="/batch-after-school">Batch After School</Link></li>
                              </ul>
                            </li>

                            {/* Student Zone */}
                            <li className="has-sub">
                              <a href="javascript:void(0)">
                                Student Zone <i className="ri-arrow-down-s-line" />
                              </a>
                              <ul className="sub-menu">
                                <li><Link href="/rules-regulations">Rules &amp; Regulations</Link></li>
                                <li><Link href="/awards-scholarships">Awards &amp; Scholarships</Link></li>
                                <li className="nav-item has-sub">
                                  <a href="#" className="nav-link dropdown-toggle">
                                    Student&apos;s Council <i className="ri-arrow-right-s-line" aria-hidden="true" style={{ color: "#a43605", float: "right" }} />
                                  </a>
                                  <ul className="dropdown-menu">
                                    <li className="nav-item"><Link className="nav-link" href="/senior-section-council">Senior Section</Link></li>
                                    <li className="nav-item"><Link className="nav-link" href="/junior-section-council">Junior Section</Link></li>
                                  </ul>
                                </li>
                                <li className="nav-item has-sub">
                                  <a href="#" className="nav-link dropdown-toggle">
                                    Examination Schedule <i className="ri-arrow-right-s-line" aria-hidden="true" style={{ color: "#a43605", float: "right" }} />
                                  </a>
                                  <ul className="dropdown-menu">
                                    <li className="nav-item"><a className="nav-link" href="https://erp.quickcampus.online/auth" target="_blank" rel="noreferrer">Schedule</a></li>
                                    <li className="nav-item"><a className="nav-link" href="https://erp.quickcampus.online/auth" target="_blank" rel="noreferrer">Syllabus</a></li>
                                  </ul>
                                </li>
                                <li><Link href="/admission">Admission</Link></li>
                              </ul>
                            </li>

                            {/* Academic Zone */}
                            <li className="has-sub">
                              <a href="javascript:void(0)">
                                Academic Zone <i className="ri-arrow-down-s-line" />
                              </a>
                              <ul className="sub-menu">
                                <li><Link href="/affiliation">Affiliation</Link></li>
                                <li className="nav-item has-sub">
                                  <a href="#" className="nav-link dropdown-toggle">
                                    Curriculum/Syllabus <i className="ri-arrow-right-s-line" aria-hidden="true" style={{ color: "#a43605", float: "right" }} />
                                  </a>
                                  <ul className="dropdown-menu">
                                    <li className="nav-item"><Link className="nav-link" href="/primary-school">Primary School</Link></li>
                                    <li className="nav-item"><Link className="nav-link" href="/middle-school">Middle School</Link></li>
                                    <li className="nav-item"><Link className="nav-link" href="/secondary-school">Secondary School</Link></li>
                                    <li className="nav-item"><Link className="nav-link" href="/senior-secondary-school">Senior Secondary School</Link></li>
                                  </ul>
                                </li>
                                <li><Link href="/streams-offered">Streams Offered</Link></li>
                                <li><Link href="/book-list">Book List 2024-25</Link></li>
                              </ul>
                            </li>

                            {/* Facilities */}
                            <li className="has-sub">
                              <a href="javascript:void(0)">
                                Facilities <i className="ri-arrow-down-s-line" />
                              </a>
                              <ul className="sub-menu">
                                <li><Link href="/birla-krida-kendra">Sarala Birla Krida Kendra</Link></li>
                                <li><Link href="/transport">Transport</Link></li>
                                <li><Link href="/educational-tours">Excursion/Educational Tours</Link></li>
                                <li><Link href="/bvn-anveshika">BVN-IAPT Anveshika</Link></li>
                                <li className="nav-item has-sub">
                                  <a href="#" className="nav-link dropdown-toggle">
                                    Clubs <i className="ri-arrow-right-s-line" aria-hidden="true" style={{ color: "#a43605", float: "right" }} />
                                  </a>
                                  <ul className="dropdown-menu">
                                    <li className="nav-item"><Link className="nav-link" href="/senior-section-club">Senior Section</Link></li>
                                    <li className="nav-item"><Link className="nav-link" href="/junior-section-club">Junior Section</Link></li>
                                  </ul>
                                </li>
                                <li><Link href="/canteen">Canteen</Link></li>
                                <li><Link href="/career-counselling-cell">Career Counselling Cell</Link></li>
                                <li><Link href="/mind-spark">Mind Spark</Link></li>
                                <li><Link href="/atal-tinkering-lab">Atal Tinkering Lab</Link></li>
                              </ul>
                            </li>

                            {/* Alumni Zone */}
                            <li className="has-sub">
                              <a href="javascript:void(0)">
                                Alumni Zone <i className="ri-arrow-down-s-line" />
                              </a>
                              <ul className="sub-menu">
                                <li><Link href="/announcements">Announcements</Link></li>
                                <li><Link href="/principal-message">Principal&apos;s Message</Link></li>
                                <li><Link href="/alumni-registration">Alumni Registration</Link></li>
                              </ul>
                            </li>

                            {/* Media */}
                            <li className="has-sub">
                              <a href="javascript:void(0)">
                                Media <i className="ri-arrow-down-s-line" />
                              </a>
                              <ul className="sub-menu">
                                <li><Link href="/media-press-coverage">Media / Press Coverage</Link></li>
                              </ul>
                            </li>

                            {/* Connect */}
                            <li className="drop-left has-sub">
                              <a href="javascript:void(0)">
                                Connect <i className="ri-arrow-down-s-line" />
                              </a>
                              <ul className="sub-menu">
                                <li><Link href="/reach-us">Reach Us</Link></li>
                                <li><Link href="/sitemap">Sitemap</Link></li>
                              </ul>
                            </li>
                          </ul>
                        </nav>
                      </div>
                    </div>

                    {/* Sidebar trigger icon */}
                    <div className="othericon">
                      <i
                        className="ri-menu-3-fill"
                        onClick={() => setSidebarOpen(true)}
                        role="button"
                        aria-label="Open sidebar"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ── Side Modal ── */}
        {sidebarOpen && (
          <div
            className="sidebarModal modal right fade show"
            style={{ display: "block" }}
            aria-modal="true"
            role="dialog"
            onClick={(e) => {
              if (e.target === e.currentTarget) setSidebarOpen(false);
            }}
          >
            <div className="modal-dialog" role="document">
              <div className="modal-content">
                <button
                  type="button"
                  className="close"
                  onClick={() => setSidebarOpen(false)}
                  aria-label="Close"
                >
                  <i className="ri-close-line" />
                </button>
                <div className="modal-body">
                  <Link href="/">
                    <img src="/images/white-logo.png" className="main-logo" alt="logo" style={{ width: "70%" }} />
                  </Link>

                  <div className="sidebar-content">
                    <h3>About Us</h3>
                    <p>
                      Shri B.K. Birla &amp; Dr. Sarala Birla laid the foundation for Birla Vidya Niketan,
                      a premier South Delhi and with their blessings the school started on 20
                      <sup>th</sup> September 1983…{" "}
                      <Link href="/school-profile">
                        <i className="ri-arrow-right-up-line" />
                      </Link>
                    </p>
                    <div className="mt-2">
                      <img src="/images/bottom-logos.jpg" className="img-fluid" alt="footer_logo" />
                    </div>
                  </div>

                  <div className="sidebar-contact-info">
                    <h3>Contact Information</h3>
                    <ul className="info-list">
                      <li>
                        <i className="ri-phone-fill" />
                        <a href="tel:+911129578960">+91-11-2957-8960/8961</a>
                      </li>
                      <li>
                        <i className="ri-mail-line" />
                        <a href="mailto:s.info@birla.ac.in">s.info@birla.ac.in</a>
                      </li>
                      <li>
                        <i className="ri-map-pin-line" />
                        Pushp Vihar, Sector-IV, New Delhi-110017, India
                      </li>
                    </ul>
                    <a className="btn btn-danger btn-sm mt-3" href="/reach-us" rel="noopener noreferrer">
                      Explore More
                    </a>
                  </div>

                  <ul className="sidebar-social-list">
                    <li><a href="https://www.facebook.com/Join2BVN/" target="_blank" rel="noopener noreferrer"><i className="ri-facebook-fill" /></a></li>
                    <li><a href="https://twitter.com/BVN_delhi" target="_blank" rel="noopener noreferrer"><i className="ri-twitter-line" /></a></li>
                    <li><a href="https://www.instagram.com/birla_vidya_niketan/" target="_blank" rel="noopener noreferrer"><i className="ri-instagram-line" /></a></li>
                    <li><a href="https://www.linkedin.com/in/birla-vidya-niketan-new-delhi-199039219" target="_blank" rel="noopener noreferrer"><i className="ri-linkedin-fill" /></a></li>
                    <li><a href="https://www.youtube.com/channel/UCmeheKJmv94r5mUGGKyaCyg" target="_blank" rel="noopener noreferrer"><i className="ri-youtube-fill" /></a></li>
                    <li><a href="https://whatsapp.com/channel/0029Va9dBv76hENjtywoHc34" target="_blank" rel="noopener noreferrer"><i className="ri-whatsapp-fill" /></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}
        {sidebarOpen && (
          <div className="modal-backdrop fade show" onClick={() => setSidebarOpen(false)} />
        )}
      </header>
    </>
  );
};

export default Header;
